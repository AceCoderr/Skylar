#include <iostream>
#include "Mylib.h"
/**
* @brief Prints out Hello CMake!
*/
void print_hello_world() {
std::cout<<"Hello CMake!";
}
