const char* logl_root = "D:/TCD Courework/Skylar Rendering Engine/Skylar";
